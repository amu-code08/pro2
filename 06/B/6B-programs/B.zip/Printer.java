public interface Printer {
    void print(int i);
}
