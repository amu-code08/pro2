public class Prob111 extends Super111{
    @Override
    public void test(){
        System.out.println("This is an example for annotation");
    }
}