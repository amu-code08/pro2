class Prob16{
    public static void main(String[] args){
        for(int i=1; i<26; i++){
            System.out.println(i + " inch = " + 2.5*i + " centimeter");
        }
    }
}