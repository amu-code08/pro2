class Prob13 {
    public static void main(String[] args) {
        String name = "Amu";
        int id = 123456;

        System.out.println("My name is " + name + " and my ID number is " + id);

        for(int i = 1; i<4; i++){
            System.out.println(i+": Hello World!");
        }
        System.out.println("Goodbye, World!");
    }
}