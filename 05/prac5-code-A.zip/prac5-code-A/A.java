public class A {
	void m1() {
		System.out.print("A:m1 ");
	}
	void m2() {
		System.out.print("A:m2 ");
	}
	void m3() {
		System.out.print("A:m3 ");
	}
}
