public class B extends A {
	void m1() {
		System.out.print("B:m1 ");
	}
	void m2() {
		super.m2();
	}
}
