public class C extends B {
	void m1() {
		System.out.print("C:m1 ");
	}
	void m2() {
		super.m2();
	}
	void m3() {
		System.out.print("C:m3 ");
	}
}
