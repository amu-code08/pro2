public class Prob102 {
 public static void main(String[] args) {
    Runnable runnable = new Runnable() {

            public void run() {
                System.out.println("Let's listen!");
            }
        };   
        runnable.run();
    }
}


